# Connecticut AI Hiring Law Compliance Kit

**$149 digital product — draft build, NOT published. No payment links created.**

Everything a Connecticut HR manager needs to act on Public Act 26-15 (the CART Act, SB 5 — signed May 27, 2026) without a lawyer in the room. Two deadlines are already live or imminent: **October 1, 2026** (AI-layoff disclosure; "AI is not a defense" to discrimination claims) and **October 1, 2027** (full AEDT notice and disclosure duties).

> **DISCLAIMER — NOT LEGAL ADVICE.** Every file in this kit is general information, not legal advice, and creates no attorney-client relationship. Connecticut employment counsel should review anything before you use it.

## Who it's for

HR managers, people-ops leads, and small-business owners in Connecticut who use — or are considering — AI tools in hiring, promotion, discipline, or firing, and need to comply without hiring a law firm first.

## File map

| File | What it is |
|---|---|
| `01-ct-cart-act-playbook.md` | The main guide: what the law is, timeline, who it covers, every duty explained, penalties, 90-day action plan, FAQs |
| `02-aedt-inventory-template.csv` | Inventory every AI tool touching employment decisions (tool, vendor, use case, data inputs, owner, risk tier, testing status) |
| `03-pre-use-notice-template.md` | Fill-in-the-blank written notice to candidates/employees (required before AEDT-influenced decisions from Oct 1, 2027) |
| `04-adverse-decision-explanation-template.md` | Fill-in-the-blank adverse-decision letter (principal reasons, AEDT's role, data used, right to examine/correct) |
| `05-human-review-log-template.csv` | Log human review of tool recommendations and overrides (recommended governance practice) |
| `06-anti-bias-testing-plan.md` | Step-by-step bias-testing program a small employer can actually run — builds the evidence courts/CHRO may weigh |
| `07-warn-act-ai-attribution-checklist.md` | What changes on mass-layoff notices from Oct 1, 2026 (100+ employee employers) |

## Key dates

- **Oct 1, 2026** — "AI is not a defense" amendment to CT Fair Employment Practices Act takes effect; WARN AI-attribution disclosure takes effect
- **Oct 1, 2027** — AEDT pre-decision notice, interaction disclosure, adverse-decision explanation, and developer information-sharing duties take effect
- **Dec 31, 2027** — Attorney General's 60-day cure window for AEDT violations expires

## Sources

All legal claims in this kit are cited to: Seward & Kissel (Aug 2026), DCI Consulting via JD Supra, Ogletree Deakins, WilmerHale, ComplianceHub.wiki, paice.work (citing chaptered text), and CT General Assembly fiscal analysis. Full URLs in `01-ct-cart-act-playbook.md`.

## Status

Draft complete. Not published, no checkout, no payment links — per build instructions.
