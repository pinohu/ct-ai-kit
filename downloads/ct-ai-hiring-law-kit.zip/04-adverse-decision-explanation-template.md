# Adverse-Decision Explanation — Template

> **DISCLAIMER — NOT LEGAL ADVICE.** Adapt to your facts and have Connecticut employment counsel review before use. Required when an adverse employment decision results from AEDT use, for tools deployed on or after **October 1, 2027** (CT CART Act, PA 26-15).

---

**EXPLANATION OF EMPLOYMENT DECISION INVOLVING AUTOMATED TECHNOLOGY**

Date: [DATE]

To: [APPLICANT / EMPLOYEE NAME]

From: [COMPANY NAME], [HR CONTACT NAME, TITLE]
Contact for questions: [EMAIL] | [PHONE]

Re: [Position applied for / employment action — e.g., "Application for [ROLE]"]

**Decision.** After review, we have decided [not to advance your application / not to select you for promotion to [ROLE] / to terminate employment effective [DATE] / ___].

**Principal reasons.** The principal reasons for this decision were:
1. [e.g., "Your fit score of 62 did not meet our advancement threshold of 70."]
2. [e.g., "The hiring manager's assessment following the screening stage."]
3. [ADD / DELETE — list the actual principal reasons; do not list reasons that did not drive the decision.]

**Role of automated technology.** [TRADE NAME OF TOOL] ([VENDOR]) was used as a substantial factor in this decision in the following way: [e.g., "The tool scored all applicants and produced the ranked list from which interviewees were selected. A human recruiter reviewed the ranked list and made the final advancement decisions."]

**Data used.** The technology analyzed the following types of personal data, from these sources:
- Data types: [e.g., resume content, assessment answers]
- Sources: [e.g., your application materials; our applicant tracking system]

**Your right to examine and correct data.** If you believe any personal data used in this decision was incorrect, you may request to examine and correct it by contacting [HR CONTACT] at [EMAIL/PHONE] within [30] days of this notice. [Describe the process: what to send, where, and what happens next.]

**Questions.** Contact [HR CONTACT] at [EMAIL/PHONE].

---

*Do not use this template to paper over a discriminatory motive — the CART Act expressly provides that AEDT use is "not a defense" to a discrimination claim under Connecticut's Fair Employment Practices Act. If the real reason for the decision differs from what the tool output, say so accurately or do not send the notice until counsel reviews.*

*Record-keeping: retain a copy with date and recipient for at least [3] years. [UNVERIFIED — no reviewed source states a CART-specific retention period; 3 years is a recommended practice. Confirm with counsel.]*
