# Pre-Decision AEDT Notice — Template

> **DISCLAIMER — NOT LEGAL ADVICE.** Adapt to your facts and have Connecticut employment counsel review before use. Required for AEDT deployed on or after **October 1, 2027** (CT CART Act, PA 26-15). Provide **before** the employment decision is made.

---

**NOTICE OF USE OF AUTOMATED EMPLOYMENT DECISION TECHNOLOGY**

Date: [DATE]

To: [APPLICANT / EMPLOYEE NAME]

From: [COMPANY NAME], [HR CONTACT NAME, TITLE]
Contact for questions: [EMAIL] | [PHONE]

**1. What this notice is.**
[COMPANY NAME] uses automated employment-related decision technology ("AEDT") as part of its [hiring / promotion / discipline / termination / ___] process. Connecticut law (Public Act 26-15, the CART Act) requires us to give you this written notice before we make a decision in which the technology plays a substantial role.

**2. The technology.**
- Trade name: [TRADE NAME OF TOOL]
- Vendor/developer: [VENDOR NAME]
- Purpose: [e.g., "to rank applicants for the [ROLE] position based on predicted job fit" — one or two plain-English sentences]

**3. The decision involved.**
[Describe the employment decision — e.g., "whether to advance your application to the interview stage for the [ROLE] position."]

**4. Personal data analyzed.**
Categories of data the tool analyzes:
- [e.g., information from your resume/application: work history, education, skills]
- [e.g., assessment responses]
- [ADD / DELETE rows as needed]

Sources of that data:
- [e.g., materials you submitted; our applicant tracking system; ___]

How the data is evaluated:
- [Plain-English description — e.g., "The tool compares your profile against patterns from past successful hires and produces a fit score from 1–100. Scores above 70 are advanced to human review." Get this language from your vendor.]

**5. Human involvement.**
[A human recruiter/hiring manager reviews the tool's output before any final decision. / Describe actual workflow — do not overstate human review.]

**6. Your right to ask questions.**
If you have questions about this technology or this notice, contact [HR CONTACT] at [EMAIL/PHONE]. [If you maintain an interactive inquiry channel, describe how to use it here.]

**7. [IF APPLICABLE — trade-secret withholding.]**
Certain technical details of [TRADE NAME] are withheld as the vendor's trade secrets under [LEGAL BASIS]. What is being withheld: [describe generally, e.g., "the precise weighting formula of the scoring model"].

---

*Record-keeping: retain a copy of each notice sent, with date and recipient, for at least [3] years. [UNVERIFIED — no reviewed source states a CART-specific retention period; 3 years is a recommended practice. Confirm with counsel.]*
