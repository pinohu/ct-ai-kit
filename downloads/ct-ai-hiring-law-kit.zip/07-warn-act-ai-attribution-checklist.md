# WARN Act AI-Attribution Checklist

> **DISCLAIMER — NOT LEGAL ADVICE.** Effective **October 1, 2026**. Have Connecticut employment counsel review your notice before filing.

## The rule

Connecticut's CART Act (PA 26-15, §26) requires that when an employer files a plant-closing or mass-layoff notice under the **federal** Worker Adjustment and Retraining Notification (WARN) Act with the Connecticut Department of Labor, the notice must disclose **whether the reductions are related to the employer's use of artificial intelligence or another technological change**. (Sources: Ogletree; paice.work, citing chaptered text.)

Connecticut is one of the first states to formally link layoff reporting to AI-driven automation. (Source: JD Supra, "Connecticut Takes Aim at AI in Employment Decisions With SB 5.")

## Who this hits

Employers covered by **federal WARN** — generally those with **100 or more employees** — filing a covered plant closing or mass layoff notice. If you are not WARN-covered, this specific duty does not apply to you (but the Oct 1, 2026 "AI is not a defense" amendment still does).

## Checklist — do this before your next RIF

- [ ] **Name the decision-maker(s).** Identify who approved the RIF and what materials they relied on (headcount models, workforce-planning tools, automation ROI analyses).
- [ ] **Ask the AI question explicitly.** Did any AI or algorithmic tool — workforce-planning software, productivity analytics, automation assessments, generative-AI efficiency projections — inform *which* roles, teams, or locations were cut? Document the answer in writing, even if the answer is "no."
- [ ] **Distinguish "AI-related" from "tech change."** The statute covers both "artificial intelligence" and "another technological change" (e.g., a software-driven reorganization, offshoring enabled by automation). If either contributed, the disclosure obligation is triggered.
- [ ] **Draft the disclosure sentence.** Example: *"The workforce reductions described in this notice are [related / not related] to the employer's use of artificial intelligence [and/or other technological change]."* If related, add one factual sentence describing the connection (e.g., "following deployment of automated customer-service systems, the Company eliminated X roles").
- [ ] **Coordinate HR + legal + operations.** The rationale for the RIF must be consistent across the WARN notice, internal communications, and any severance materials. Inconsistencies become exhibits.
- [ ] **Preserve contemporaneous documentation.** Keep the analyses and meeting notes supporting the stated cause. The state now has a statutory hook to ask *why* people were laid off.
- [ ] **File on time.** This is an addition to your existing WARN obligations, not a replacement — the federal 60-day notice clock still runs.

## Common trap

A RIF "caused by" a reorganization that was itself *designed around* AI-driven productivity gains is arguably AI-related. When in doubt, disclose and describe — the statute asks *whether* there is a relation, and a transparent "yes, here is how" beats a "no" that discovery later contradicts.
