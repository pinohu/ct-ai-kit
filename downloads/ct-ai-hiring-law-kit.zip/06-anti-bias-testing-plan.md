# Anti-Bias Testing Plan — Step by Step

> **DISCLAIMER — NOT LEGAL ADVICE.** The CART Act does not mandate a specific testing methodology. What it does: effective **Oct 1, 2026**, Connecticut's Fair Employment Practices Act provides that AEDT use is "not a defense" to a discrimination complaint — but courts and the CHRO **may consider evidence of anti-bias testing** (quality, efficacy, recency, scope, results, and your response) as a mitigating factor. This plan builds that evidence. Have counsel review the plan and keep results privileged where appropriate.

## Why test now

The disclosure duties start Oct 1, 2027, but the liability shift starts Oct 1, 2026. Testing you do *this quarter* is the evidence a court may weigh later. (Sources: Ogletree; Sewkis.)

## Step 1 — Pick the tool (Week 1)

Start with your **highest-risk AEDT**: usually the resume screener or whatever makes the most reject/advance calls. One tool per testing cycle. Record it in file 02 (inventory), column `testing_status`.

## Step 2 — Define the decision and the population (Week 1)

Write down, in one paragraph:
- The exact decision the tool influences (e.g., "advance to interview for hourly warehouse roles")
- The population it was applied to in the last 6–12 months (dates, requisition IDs)
- The tool's output scale (e.g., score 1–100, threshold 70)

## Step 3 — Pull the data (Weeks 2–3)

From your ATS/HRIS, export for each candidate in the population:
- Tool output (score/rank/recommendation) and the threshold applied
- Final human decision (advanced / rejected)
- Available demographic fields **as voluntarily provided** (race, sex, age band) — never infer demographics; use only what candidates disclosed, and consult counsel on data handling

[UNVERIFIED — best practice, not statute: the CART Act prescribes no testing methodology. The approach below mirrors the four-fifths rule commonly used in US employment testing.]

## Step 4 — Run the disparity screen (Week 4)

For each demographic group with a meaningful sample size:
1. Compute the **selection rate** = advanced ÷ total per group
2. Compute the **ratio** = each group's rate ÷ highest group's rate
3. Flag any ratio **below 0.80** (the "four-fifths rule") for deeper review

Also check: does the tool systematically down-rank any group at *specific score bands*? Averages can hide cliffs.

You do not need fancy software — a spreadsheet pivot table does this. If you have a statistician or an I-O psychologist, use them; if not, document exactly what you did.

## Step 5 — Investigate flags (Weeks 5–6)

For each flagged disparity:
- Is a specific input driving it (e.g., employment gaps, zip code, name-derived features)? Ask your vendor for feature-importance information — they owe you cooperation under the Act's developer duties.
- Is the disparity job-related and consistent with business necessity? Write down the analysis.
- Could a less discriminatory alternative achieve the goal (different threshold, blinded inputs)?

## Step 6 — Remediate and document (Week 7)

For each finding, record: **finding → action taken → owner → date**. Actions may include re-thresholding, removing an input, adding human review at a score band, or replacing the tool. "No action — disparity not found" is a valid outcome; write it down anyway.

## Step 7 — File the evidence pack (Week 8)

Keep in one place, dated and versioned:
1. This plan (which tool, which population, which dates)
2. Methodology memo (what you computed and why)
3. Results tables
4. Remediation log
5. Vendor correspondence

This pack is what you'd hand counsel if the CHRO ever asks about "quality, efficacy, recency, scope" of your testing.

## Step 8 — Repeat on a cadence

- **Re-test** each production AEDT at least **annually**, and after any material model, threshold, or vendor change. [UNVERIFIED — cadence is recommended practice; the Act sets no re-testing schedule.]
- **Log human overrides** continuously in file 05 — a pattern of overrides in one direction is itself a bias signal.

## If you find a serious disparity

Stop and call counsel before changing anything in production. Remediation done wrong (e.g., secret race-conscious adjustments) can create its own liability. The goal is a *documented, job-related, consistently applied* process — not a particular statistical outcome.
